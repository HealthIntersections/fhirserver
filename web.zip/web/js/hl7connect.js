function hchelp(s) 
{
 window.open('/doco/'+s, "HL7ConnectHelp", "status=0,toolbar=0,location=0,height=500,width=700,resizable=1,directories=0,menubar=0,scrollbars=1");
}
